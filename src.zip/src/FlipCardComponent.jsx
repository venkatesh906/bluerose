import React from 'react';
import './FlipCardComponent.css';

const FlipCardComponent = () => {
  const cards = [
    {
      frontImage: 'https://bluerose-tech.com/wp-content/uploads/2016/01/13.jpg',
      frontText: 'Industry Focus',
      backText: 'Blue Rose thinks that an industry emphasis yields the best results. Put another way, we find out what our clients need and then provide it via the prism of the industry.'
    },
    {
      frontImage: 'https://bluerose-tech.com/wp-content/uploads/2023/05/data-security-system-shield-protection-verificatio-2022-12-16-00-42-27-utc-scaled.jpg',
      frontText: 'Technology Excellence',
      backText: 'We leverage technology as a critical business lever by choosing the most appropriate technological solutions in line with both short- and long-term goals.'
    },
    {
      frontImage: 'https://bluerose-tech.com/wp-content/uploads/2020/04/datawarehousing.jpg',
      frontText: 'Go The Extra Mile',
      backText: 'Our agile teams, who welcome new ideas and innovations, concentrate on providing customer-centric solutions in a setting that fosters learning and development.'
    },
    {
      frontImage: 'https://bluerose-tech.com/wp-content/uploads/2020/04/rpa-page-overview.jpg',
      frontText: 'Agile And Adaptable',
      backText: 'We use data-driven insights, agile methodologies, and technology to deliver quantifiable outcomes quickly and effectively.'
    }
  ];

  return (
    <div>
      <h2 className="heading">Our Culture</h2>
      <div className="grid-container">
        {cards.map((card, index) => (
          <div key={index} className="flip-box">
            <div className="flip-card">
              <div className="front" style={{ backgroundImage: `url(${card.frontImage})` }}>
                <div className="content text-center">
                  {card.frontText}
                </div>
              </div>
              <div className="back">
                <div className="content">
                  {card.backText}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FlipCardComponent;
