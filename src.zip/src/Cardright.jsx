import React from 'react';

const Cardright = ({ title, description, imageUrl }) => {
    return (
        <div className="relative bg-white rounded-lg overflow-hidden shadow-lg m-4 w-72">
            <div className="h-48 bg-cover bg-center" style={{ backgroundImage: `url(${imageUrl})` }}>
                <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-end p-4">
                    <h2 className="text-white text-xl font-semibold">{title}</h2>
                    <p className="text-white">{description}</p>
                </div>
            </div>
        </div>
    );
};

export default Cardright;
