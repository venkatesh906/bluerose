import React, { useState } from 'react';
import Card from './Card';
import './App.css';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

const videoData = [
    {
        title: 'BAU | Business As Usual',
        videoUrl: 'https://www.youtube.com/watch?v=3DNTHFBVMlM',
    },
    {
        title: 'BlueRose Drives Generative AI Progress',
        videoUrl: 'https://www.youtube.com/watch?v=fXadkfvKZ4U',
    },
    {
        title: 'ServiceGenAI',
        videoUrl: 'https://www.youtube.com/watch?v=tJHjjTdXktU',
    }
];

const Videocard = () => {
    const [open, setOpen] = useState(false);
    const [selectedVideo, setSelectedVideo] = useState('');

    const handleCardClick = (videoUrl) => {
        setSelectedVideo(videoUrl);
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
        setSelectedVideo('');
    };

    return (
        <div className="app bg-gray-100 min-h-screen flex flex-col items-center p-8">
            <h1 className="text-3xl font-bold mb-8">Visual Insights</h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {videoData.map((video, index) => (
                    <Card
                        key={index}
                        title={video.title}
                        videoUrl={video.videoUrl}
                        onClick={() => handleCardClick(video.videoUrl)}
                    />
                ))}
            </div>
            <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
                <DialogTitle>Video Player</DialogTitle>
                <DialogContent>
                    {selectedVideo && (
                        <div className="video-container">
                            <iframe
                                width="100%"
                                height="400px"
                                src={selectedVideo.replace('watch?v=', 'embed/')}
                                frameBorder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen
                                title="YouTube video player"
                            ></iframe>
                        </div>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default Videocard;
