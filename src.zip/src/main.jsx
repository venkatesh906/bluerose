import React from 'react'
import ReactDOM from 'react-dom/client'

import './index.css'
import Navbar from './Navbar.jsx'
import Homepage from './Homepage.jsx'
import App from './App.jsx'
import Videocard from './Videocard.jsx'
import Achievements from './Achievements.jsx'
import FlipCardComponent from './FlipCardComponent.jsx'
import Footer from './Footer.jsx'


ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Navbar />
    <Homepage/>
    <App/>
    <Videocard/>
    <FlipCardComponent/>
    <Achievements/>
    <Footer/>
    
    
  </React.StrictMode>,
)
