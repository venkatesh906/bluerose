import React from 'react';
import Cardright from './Cardright';


const cardData = [
    {
        title: 'PEGA 1',
        description: 'Experience the power of industry-focused solutions…',
        imageUrl: 'https://www.bluerose-tech.com/wp-content/uploads/2023/10/BAU.jpg',
    },
    {
        title: 'PEGA 2',
        description: 'BRT SAP offerings on ECC, S/4HANA and Cloud…',
        imageUrl: 'https://www.bluerose-tech.com/wp-content/uploads/2023/06/brt-core-value-passion.jpg',
    },
    {
        title: 'PEGA 3',
        description: 'Innovative solutions for your business needs…',
        imageUrl: 'https://www.bluerose-tech.com/wp-content/uploads/2023/10/human-like-robot-and-artificial-intelligence-2022-01-06-00-25-53-utc-scaled.jpg',
    },
    {
        title: 'PEGA 4',
        description: 'Enhancing productivity with advanced technology…',
        imageUrl: 'https://www.bluerose-tech.com/wp-content/uploads/2023/10/human-like-robot-and-artificial-intelligence-2022-01-06-00-25-53-utc-scaled.jpg',
    },
    {
        title: 'PEGA 5',
        description: 'Transforming industries with cutting-edge solutions…',
        imageUrl: 'https://www.bluerose-tech.com/wp-content/uploads/2023/10/human-like-robot-and-artificial-intelligence-2022-01-06-00-25-53-utc-scaled.jpg',
    },
    {
        title: 'PEGA 6',
        description: 'Driving innovation with tailored approaches…',
        imageUrl: 'https://www.bluerose-tech.com/wp-content/uploads/2023/10/human-like-robot-and-artificial-intelligence-2022-01-06-00-25-53-utc-scaled.jpg',
    }
];

const Homepage = () => {
    return (
        <div className="app relative min-h-screen">
            <div className="absolute inset-0 bg-cover bg-center opacity-30" style={{ backgroundImage: `url('https://www.bluerose-tech.com/wp-content/uploads/2023/10/human-like-robot-and-artificial-intelligence-2022-01-06-00-25-53-utc-scaled.jpg')` }}></div>
            <div className="relative grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
                {cardData.map((card, index) => (
                    <Cardright
                        key={index}
                        title={card.title}
                        description={card.description}
                        imageUrl={card.imageUrl}
                    />
                ))}
            </div>
        </div>
        
    );
};

export default Homepage;
