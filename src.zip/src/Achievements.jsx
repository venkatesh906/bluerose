import React from 'react';
import CountUp from 'react-countup';
import { useInView } from 'react-intersection-observer';
import { FaUser, FaRocket, FaGlobe, FaTrophy } from 'react-icons/fa';
import { FaUsers } from "react-icons/fa"; 
import './Achievements.css'; // Ensure the CSS file is correctly linked

const Achievements = () => {
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.5,
    });

    return (
        <div className="achievements-container" ref={ref}>
            <h1 className="achievements-title">Our Achievements!!</h1>
            <div className="achievements-grid">
                <div className="achievement">
                    <FaUsers className="icon" />
                    <div className="text-container">
                        <div className="count">
                            {inView && <CountUp start={0} end={60} duration={2} />}
                            +
                        </div>
                        <span className="achievement-description">Active trusting clients</span>
                    </div>
                </div>
                <div className="achievement">
                    <FaRocket className="icon" />
                    <div className="text-container">
                        <div className="count">
                            {inView && <CountUp start={0} end={5} duration={2} />}
                            +
                        </div>
                        <span className="achievement-description">A diverse range of exceptional products</span>
                    </div>
                </div>
                <div className="achievement">
                    <FaGlobe className="icon" />
                    <div className="text-container">
                        <div className="count">
                            {inView && <CountUp start={0} end={22} duration={2} />}
                            +
                        </div>
                        <span className="achievement-description">Countries where we have presence</span>
                    </div>
                </div>
                <div className="achievement">
                    <FaTrophy className="icon" />
                    <div className="text-container">
                        <div className="count">
                            {inView && <CountUp start={0} end={6} duration={2} />}
                            +
                        </div>
                        <span className="achievement-description">Recognized with prestigious accolades</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Achievements;
