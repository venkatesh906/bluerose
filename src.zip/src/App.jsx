import React from 'react';
import './App.css';

const App = () => {
    return (
        <div className="app bg-gradient-to-r from-blue-300 to-blue-500 min-h-screen flex items-center justify-center">
            <div className="bg-white shadow-lg rounded-lg flex overflow-hidden w-3/4 max-w-4xl">
                {/* Left side (video or content) */}
                <div className="w-1/2">
                    <iframe
                        src="https://www.youtube.com/embed/GWx0Xw2A8AA"
                        frameBorder="0"
                        allow="autoplay; encrypted-media"
                        allowFullScreen
                        className="w-full h-full"
                    ></iframe>
                </div>
                {/* Right side (text content) */}
                <div className="w-1/2 p-8">
                <p>At BRT, we’re taking a client-centric approach to becoming the leading business services partner for companies worldwide.</p>
                    <p className="mb-4">Blue Rose provides solutions which help global companies to perform at their peak level.</p>
                    <p className="mb-4">By combining deep industry experience, proven track record, end to end innovative solutions and client focus, Blue Rose collaborates with clients to help them achieve their business objectives by aligning our teams with clients’ business strategies to achieve top-to-bottom line results.</p>
                    <p>We operate in 22+ countries worldwide.</p>
                </div>
            </div>
        </div>
    );
};

export default App;

