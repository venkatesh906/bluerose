import React from 'react';
import { FaFacebookF, FaTwitter, FaInstagram, FaYoutube, FaLinkedin } from 'react-icons/fa';
import './Footer.css'

const Footer = () => {
  return (
    <footer className="bg-blue-900 text-white py-8">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="w-1/2 text-left">
          <h2 className="text-xl font-bold mb-4 text-gray-400">Get In Touch</h2>
          <p className="mb-4">
            With a footprint spanning across continents, our company is strategically positioned to serve you wherever you are. Feel free to reach out to any of our international locations or contact our centralized support team for seamless assistance.
          </p>
          <button className="bg-green-500 text-white px-4 py-2 rounded-md">View Global Presence</button>
        </div>
        <div className="w-1/2 text-right">
          <h2 className="text-xl font-bold mb-4 text-gray-400">Get Subscribed</h2>
          <div className="mb-4">
            <input
              type="email"
              placeholder="Enter your email*"
              className="p-2 rounded-l-md text-black"
            />
            <button className="bg-blue-700 p-2 rounded-r-md">Subscribe</button>
          </div>
          <div className="flex justify-end space-x-4">
            <a href="#" className="socialContainer containerOne">
              <FaFacebookF className="socialSvg" />
            </a>
            <a href="#" className="socialContainer containerTwo">
              <FaTwitter className="socialSvg" />
            </a>
            <a href="#" className="socialContainer containerThree">
              <FaInstagram className="socialSvg" />
            </a>
            <a href="#" className="socialContainer containerFour">
              <FaYoutube className="socialSvg" />
            </a>
            <a href="#" className="socialContainer containerFive">
              <FaLinkedin className="socialSvg" />
            </a>
          </div>
        </div>
      </div>
      <div className="container mx-auto px-4 text-center mt-8 border-t border-gray-700 pt-4">
        <p className="text-gray-400">
          &copy; Copyright 2009 - 2024 | BlueRose Technologies All Rights Reserved | <a href="#" className="text-gray-400">Privacy Policy</a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;
