import React, { useState, useRef, useEffect } from 'react';
import { FaChevronDown } from 'react-icons/fa';

import AboutSection from './components/AboutSection.jsx';

const Navbar = () => {
  const [openDropdown, setOpenDropdown] = useState(null);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpenDropdown(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleDropdown = (name) => {
    setOpenDropdown(openDropdown === name ? null : name);
  };

  return (
    <div>
      <nav className="fixed top-0 left-0 w-full flex items-center justify-between bg-white p-4 shadow-md z-10">
        <div className="flex items-center">
          <img
            src="https://www.bluerose-tech.com/wp-content/uploads/2024/02/Company-Logo-Full-Color-website.png"
            alt="Company Logo"
            className="h-12"
          />
        </div>
        <ul className="flex space-x-6">
          <li className="text-black font-bold hover:text-blue-500 cursor-pointer">Home</li>
          <li
            className="text-black font-bold hover:text-blue-500 cursor-pointer flex items-center"
            onClick={() => handleDropdown('WhoWeAre')}
          >
            Who We Are <FaChevronDown className="ml-1" />
          </li>
          <li
            className="text-black font-bold hover:text-blue-500 cursor-pointer flex items-center"
            onClick={() => handleDropdown('WhatWeDo')}
          >
            What We Do <FaChevronDown className="ml-1" />
          </li>
          <li
            className="text-black font-bold hover:text-blue-500 cursor-pointer flex items-center"
            onClick={() => handleDropdown('WhoWeServe')}
          >
            Who We Serve <FaChevronDown className="ml-1" />
          </li>
          <li
            className="text-black font-bold hover:text-blue-500 cursor-pointer flex items-center"
            onClick={() => handleDropdown('Products')}
          >
            Products <FaChevronDown className="ml-1" />
          </li>
          <li
            className="text-black font-bold hover:text-blue-500 cursor-pointer flex items-center"
            onClick={() => handleDropdown('Careers')}
          >
            Careers <FaChevronDown className="ml-1" />
          </li>
          <li className="text-black font-bold hover:text-blue-500 cursor-pointer">Contact Us</li>
        </ul>
      </nav>

      {openDropdown && (
        <div ref={dropdownRef} className="fixed top-16 left-0 w-full bg-white p-4 shadow-md z-10">
          {openDropdown === 'WhoWeAre' && <div><AboutSection/></div>}
          {openDropdown === 'WhatWeDo' && <div>Content for What We Do</div>}
          {openDropdown === 'WhoWeServe' && <div>Content for Who We Serve</div>}
          {openDropdown === 'Products' && <div>Content for Products</div>}
          {openDropdown === 'Careers' && <div>Content for Careers</div>}
        </div>
      )}
    </div>
  );
};

export default Navbar;
