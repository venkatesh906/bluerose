// src/components/AboutSection.js
import React from 'react';
import { FaUsers, FaHandshake, FaHandsHelping, FaSuitcase, FaNewspaper, FaBlog } from 'react-icons/fa';

const AboutSection = () => {
  return (
    <div className="container mx-auto p-4 flex flex-col md:flex-row justify-between">
      {/* Left Section */}
      <div className="md:w-1/2 lg:w-2/5 mb-6 md:mb-0">
        <h2 className="text-4xl font-bold hover:text-blue-500  cursor-pointer text-blue-300">About BlueRose Technologies</h2>
        <p className="text-gray-600">Over a Decade of Excellence in Global Technology Services,</p>
        <p className="text-gray-600 mt-4">
          BlueRose Technologies is a leading global provider of technology services and digital solutions.
          Our mission is to empower our clients worldwide to thrive in today’s rapidly evolving landscape...
        </p>
        {/* <a href="#" className="text-blue-500 mt-4 inline-block">Read more about us</a> */}
      </div>
      {/* Right Section */}
      <div className="md:w-1/2 lg:w-3/5 grid grid-cols-2 sm:grid-cols-3 gap-4 text-center">
        <div className="flex flex-col items-center">
          <FaUsers size="2em" className="mb-2 hover:text-blue-500 cursor-pointer" />
          <span>Leadership</span>
        </div>
        <div className="flex flex-col items-center">
          <FaHandshake size="2em" className="mb-2 hover:text-blue-500 cursor-pointer" />
          <span>Partners</span>
        </div>
        <div className="flex flex-col items-center">
          <FaHandsHelping size="2em" className="mb-2 hover:text-blue-500 cursor-pointer" />
          <span>CSR Activities</span>
        </div>
        <div className="flex flex-col items-center">
          <FaSuitcase size="2em" className="mb-2 hover:text-blue-500 cursor-pointer" />
          <span>Workforce Management</span>
        </div>
        <div className="flex flex-col items-center">
          <FaNewspaper size="2em" className="mb-2 hover:text-blue-500 cursor-pointer" />
          <span>Newsletter</span>
        </div>
        <div className="flex flex-col items-center">
          <FaBlog size="2em" className="mb-2 hover:text-blue-500 cursor-pointer" />
          <span>Blog</span>
        </div>
      </div>
    </div>
  );
};

export default AboutSection;
