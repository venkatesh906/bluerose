import React from 'react';
import { FaPlay } from 'react-icons/fa';

const getYoutubeThumbnail = (url) => {
    const videoId = url.split('v=')[1];
    return `https://img.youtube.com/vi/${videoId}/0.jpg`;
};

const Card = ({ title, videoUrl, onClick }) => {
    const imageUrl = getYoutubeThumbnail(videoUrl);

    return (
        <div className="relative group overflow-hidden rounded-lg shadow-lg" onClick={onClick}>
            <img className="w-full h-48 object-cover" src={imageUrl} alt={title} />
            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <FaPlay className="w-16 h-16 text-white" />
            </div>
            <div className="p-4">
                <h2 className="text-lg font-bold">{title}</h2>
            </div>
        </div>
    );
};

export default Card;
