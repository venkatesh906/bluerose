import React from 'react';


const homepage2 = () => {
    return (
        <div className="app bg-gradient-to-r from-blue-300 to-blue-500 min-h-screen flex items-center justify-center">
            <div className="bg-white shadow-lg rounded-lg flex overflow-hidden w-3/4 max-w-4xl">
                <div className="w-1/2">
                    <iframe 
                        className="w-full h-full" 
                        src="https://www.youtube.com/embed/E5xmbDI8jMI?autoplay=0&enablejsapi=1&wmode=opaque" 
                        frameBorder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowFullScreen
                    ></iframe>
                </div>
                <div className="w-1/2 p-8">
                    <h1 className="text-2xl font-semibold mb-4">At BRT, we’re taking a client-centric approach to becoming the leading business services partner for companies worldwide.</h1>
                    <p className="mb-4">Blue Rose provides solutions which help global companies to perform at their peak level.</p>
                    <p className="mb-4">By combining deep industry experience, proven track record, end to end innovative solutions and client focus, Blue Rose collaborates with clients to help them achieve their business objectives by aligning our teams with clients’ business strategies to achieve top-to-bottom line results.</p>
                    <p>We operate in 22+ countries worldwide.</p>
                </div>
            </div>
        </div>
    );
};

export default homepage2;
